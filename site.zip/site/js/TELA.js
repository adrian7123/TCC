//.  VARIAVEIS DA TELA 

var ALTURA = innerHeight,
	LARGURA = innerWidth;
	
//alert(LARGURA)
	
	
if(LARGURA < 530){

	
}else {
	console.log('sem alterações no momento')
}




