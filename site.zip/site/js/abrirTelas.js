function abrirMain() {
	window.location.href = "main.html";

}